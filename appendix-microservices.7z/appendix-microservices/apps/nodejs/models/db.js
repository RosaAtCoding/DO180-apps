
module.exports.params = {
    dbname: "items",
    username: "user1",
    password: "mypa55",
    params: {
        host: "mysql",
        port: "3306",
        dialect: 'mysql'
    }
};

